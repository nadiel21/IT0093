# Campus Companion — M4 (Exercise 4)

Persistence: UserDefaults (welcome screen) and Core Data (announcements), plus the Part 3 challenge. Includes everything from M3.

## Open
Double-click `CampusCompanion.xcodeproj` (classic project format, opens in Xcode 14+; deployment target iOS 15), choose an iPhone simulator, press ⌘R.

## Folder layout (Xcode folders, auto-synced)
- `App/` — AppDelegate, SceneDelegate
- `Controllers/` — ViewController, DetailViewController, AnnouncementsViewController
- `Models/` — `CampusCompanion.xcdatamodeld` (CampusAnnouncement entity: title, date, category, priority, postedBy; Codegen = Class Definition)
- `Views/` — AnnouncementCell (custom UITableViewCell)
- `Base.lproj/Main.storyboard` — Nav → Welcome → (Detail | Announcements list → Detail)

## Identifiers (must match exactly)
- Cell reuse identifier: `AnnouncementCell`
- Segues: `ShowDetailSegue` (Explore Campus), `ShowAnnouncementDetailSegue` (row tap)
- "Campus Announcements" button uses a direct Show segue (no identifier)

## Test checklist
1. Campus Announcements → 6 rows with megaphone icons; "Campus Wi-Fi Maintenance Notice" is red with an alert icon.
2. Scroll up/down repeatedly → only the Wi-Fi row stays red (cell reuse is correct).
3. Tap a row → Detail shows title, category, date, priority, posted by.
4. Back to welcome → Explore Campus flow still shows the personalized welcome message.

## Exercise 4 additions
- UserDefaults keys (`DefaultsKey` enum): `studentName`, `notificationsEnabled`, `selectedRoleIndex`
- Core Data stack in `AppDelegate` (`persistentContainer`, `saveContext()`)
- Announcements are seeded once (count check), added via the "+" bar button (alert), and deleted by swiping left
- "Reset Preferences" button on the welcome screen clears the three saved values and resets the fields

## Exercise 4 test checklist
1. Enter a name, switch on, pick Faculty, tap Explore Campus, fully terminate, relaunch → values restored.
2. Tap Reset Preferences → name empty, switch off, Student selected (no relaunch needed).
3. Campus Announcements → 6 seeded rows in date order; relaunch → still 6 (no duplicates).
4. Tap + → add title/category → row appears; relaunch → still there.
5. Swipe a row left → Delete; relaunch → stays deleted.
