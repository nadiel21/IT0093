//
//  AnnouncementCell.swift
//  CampusCompanion
//

import UIKit

class AnnouncementCell: UITableViewCell {

    @IBOutlet weak var categoryIconImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!

    func configure(with announcement: CampusAnnouncement) {
        // Core Data generates String? properties, so unwrap each with a safe default.
        let title = announcement.title ?? ""
        let category = announcement.category ?? ""
        let date = announcement.date ?? ""

        titleLabel.text = title

        // Every visual property is set in BOTH branches so a reused cell
        // never keeps the Urgent styling from a previous row.
        if (announcement.priority ?? "Normal") == "Urgent" {
            dateLabel.text = "\(category) • URGENT • \(date)"
            categoryIconImageView.image = UIImage(systemName: "exclamationmark.circle.fill")
            categoryIconImageView.tintColor = .systemRed
            titleLabel.textColor = .systemRed
            dateLabel.textColor = .systemRed
            contentView.backgroundColor = UIColor.systemRed.withAlphaComponent(0.1)
        } else {
            dateLabel.text = "\(category) • \(date)"
            categoryIconImageView.image = UIImage(systemName: "megaphone.fill")
            categoryIconImageView.tintColor = .systemBlue
            titleLabel.textColor = .label
            dateLabel.textColor = .secondaryLabel
            contentView.backgroundColor = .clear
        }
    }
}
